package com.example.fa_10

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
